<?php
// Sertakan autoloader dari Composer
require 'vendor/autoload.php';

// Import kelas yang diperlukan dari library
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Logo\Logo;

// Inisialisasi variabel untuk menampung URI data gambar QR
$qrCodeUri = '';

// Cek apakah form telah disubmit (metode POST) dan input 'data' tidak kosong
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['data'])) {
    
    // Ambil data teks atau URL dari form
    $data = $_POST['data'];
    
    // Buat instance QR Code dengan data dari user
    $qrCode = QrCode::create($data)
                ->setSize(400) // Atur ukuran QR code
                ->setMargin(10); // Atur margin di sekitar QR code

    // Logo di tengah (harus PNG atau JPG)
    $logo = Logo::create(__DIR__ . '/logo.png') // Path logo Anda
    ->setResizeToWidth(75);

    // Buat instance writer untuk format PNG
    $writer = new PngWriter();
    
    // Generate hasil QR code dari writer
    $result = $writer->write($qrCode, $logo);
    
    // Dapatkan URI data dari gambar QR code (untuk disematkan langsung di HTML)
    $qrCodeUri = $result->getDataUri();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generator QR Code PHP</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f4f4f9;
            margin: 0;
        }
        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #333;
        }
        form {
            margin-top: 1.5rem;
        }
        input[type="text"] {
            width: 80%;
            padding: 0.8rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 0.8rem 1.5rem;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 1rem;
        }
        button:hover {
            background-color: #0056b3;
        }
        .qr-code {
            margin-top: 2rem;
        }
        img {
            border: 5px solid white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Generator QR Code Sederhana</h1>
        <p>Masukkan teks atau URL untuk dibuatkan QR Code.</p>
        
        <form method="POST" action="">
            <input type="text" name="data" placeholder="Contoh: https://www.google.com" required>
            <br>
            <button type="submit">Buat QR Code</button>
        </form>

        <?php if ($qrCodeUri): ?>
            <div class="qr-code">
                <h2>QR Code Anda:</h2>
                <img src="<?= htmlspecialchars($qrCodeUri) ?>" alt="Generated QR Code">
                <p><small>Klik kanan untuk menyimpan gambar.</small></p>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>